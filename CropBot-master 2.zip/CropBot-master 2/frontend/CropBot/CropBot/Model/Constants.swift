/*
 This is a struct containing information that
 is constant throughout the program.
 
 Copyright © 2019 Nikolas Ioannou. All rights reserved.
*/

import UIKit

struct Constants {
    
}
