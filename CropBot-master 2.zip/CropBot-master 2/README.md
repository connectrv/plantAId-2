# CropBot

<img src="https://user-images.githubusercontent.com/30766392/73939737-1c38a480-4910-11ea-8d09-74e34a94f97b.png" width="30%">               <img src="https://user-images.githubusercontent.com/30766392/73939764-28bcfd00-4910-11ea-9ff6-da9eae844ba7.png" width="30%"/>

<img src="https://user-images.githubusercontent.com/30766392/73939775-2c508400-4910-11ea-85ca-0d99835922cd.png" width="30%"/>              <img src="https://user-images.githubusercontent.com/30766392/73939784-2fe40b00-4910-11ea-8514-08a17a4651fa.png" width="30%"/>

<img src="https://user-images.githubusercontent.com/30766392/73939791-32466500-4910-11ea-82b0-482301976045.png" width="30%"/>
