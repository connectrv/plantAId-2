The API is located at this repo: https://github.com/sagek21/CropBotApi
